function [y]=threeone(x)
y=zeros(1,length(x));
for i=2:(length(x)-1)
    y(i)=3*x(i-1) - 2*x(i) + x(i+1);
end
y(1) = -2*x(1) + x(2);
y(length(x))= 3*x(length(x)-1)-2*x(length(x));
end