%%% TP 2- %%%
%%% Student Ezequiel De La Rosa
%%% Student Luca Canalini
%%% 6/11/2016 

% REMINDER 1

F=1; 
t=0:0.2:20;
funsin=sin(2*pi*F*t);
%plot(funsin)

% sampling sin function at 20hz
fs=20;
sampx=sin(2*pi*(F/fs)*t);
%subplot(1,2,1), plot(funsin)
%subplot(1,2,2), plot(sampx)

%%% EXERCISE 1 %%%%
stEx1=step(4,20);
output=casualucaeze(stEx1);
% it is not casual because started one sample previous to the original
% function

%1.2. we modify the function as y=(x(i)+x(i-1))/2

outputCas=casualucaeze2(stEx1);
subplot(3,1,1), stem(stEx1)
title('original step')
subplot(3,1,2), stem(output)
title('Function y no-casual')
subplot(3,1,3), stem(outputCas)
title('Casual proposed Y function')

%%%%% EXERCISE 2
% we enter the previous step(4,20) function to our cumulative function
outPrim=prim(stEx1);
figure, subplot (2,1,1), stem(stEx1)
subplot(2,1,2), stem(outPrim)

%No, because if the amount of samples tends to infinite, also the output
%tends to infinite.

%2.1. IMULSE RESPONSER OF  OUR PRIM FUNCTION 
impulseLE= zeros(20);
impulseLE(5)=1;

outputImp=prim(impulseLE);
figure, subplot (2,1,1), stem(impulseLE)
subplot(2,1,2), stem(outputImp)

% now our function is stable (limited between 0 and 1)

% 2.3
outputX2Y=x2y(impulseLE);
figure, subplot (2,1,1), stem(impulseLE)
subplot(2,1,2), stem(outputX2Y)
% we can see it is not stable (divergent output for incresing amount of samples)

%2.4 
outputTURTS=IlikeTurtles(impulseLE);
figure, subplot (2,1,1), stem(impulseLE)
subplot(2,1,2), stem(outputTURTS)

% now is stable, it is limited between 0 and 1

%%% EXERCISE 3
%3.1
xa = [0 0 0 0 1 2 3 4 5 0 0 0 0 0 0 0 0 0 0];
xb = [0 0 0 0 0 0 0 0 0 4 3 2 1 0 0 0 0 0 0];
outthreeone1 = threeone(xa);
outthreeone2 = threeone(xb);
figure, subplot(2,1,1), stem(outthreeone1)
subplot(2,1,2), stem(outthreeone2)

%3.2.1 LINEARITY
xsum = 3*xa+2*xb;
outthreeone3=threeone(xsum);
outthreeone4 = 3*outthreeone1 + 2*outthreeone2;
figure, subplot(2,1,1), stem(outthreeone3)
subplot(2,1,2), stem(outthreeone4)
s = isequal(outthreeone3, outthreeone4);
%from this plot, we see that is linear <- outthreeone3 = outthreeone4
%also from isequal we see that the two outputs are the same

% 3.2.2 INVARIANCE
%WE DELAYED xa input and check its output
xad=[0 0 0 1 2 3 4 5 0 0 0 0 0 0 0 0 0 0 0];
outdelay=threeone(xad);
figure, subplot(2,1,1), stem(outdelay)
subplot(2,1,2), stem(outthreeone1)
%AS WE CAN OBSERVE FROM THE PLOT, WHEN YOU SHIFT THE INPUT, ALSO THE OUTPUT
%IS SHIFTED -> ACCOMPLISHING INVARIANCY CRITERIA

%3.3

d1 = not_invariant(xa);
d2 = not_invariant(xb);
xsum1 = 3*d1+2*d2;
outthreeoneN1 = not_invariant(xsum1);
outthreeoneN2 = 3*d1 + 2*d2;
figure, subplot(2,1,1), stem(outthreeoneN1)
subplot(2,1,2), stem(outthreeoneN2)
s1 = isequal(outthreeoneN1, outthreeoneN2);
%from this plot, we see that is NOT linear <- outthreeone3 != outthreeone4
%also from isequal we see that the two outputs are the different

% 3.2.2 INVARIANCE
%WE DELAYED xa input and check its output
xad=[0 0 0 1 2 3 4 5 0 0 0 0 0 0 0 0 0 0 0];
outdelay2= not_invariant(xad);
figure, subplot(2,1,1), stem(outdelay2)
subplot(2,1,2), stem(outthreeoneN1)



