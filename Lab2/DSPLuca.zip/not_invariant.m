function [y]=not_invariant(x)
y=zeros(1,length(x));
for i=1:length(x)
    y(i)=i*x(i)+2*(x(i)^3);
end
end