%convFn2
%lenawe loveu

function [convMatrix]=convFn2(m1,m2)

%m1=[1 2 1 2; 0 1 -1 1];
%m2=[2 -1 2; -1 -2 0;1 -1 2];
signal2= flipdim(flipdim(m2,1),2);

[rS,cS]=size(m1);
[rF,cF]=size(m2);
extraR=2*floor((rF/2));

extMat=zeros(rS+extraR, cS+extraR);
[rE,cE]=size(extMat);
extMat(((extraR/2)+1):(rE-(extraR/2)),((extraR/2)+1):(cE-(extraR/2)))=m1;
convMatrix=zeros(rS,cS); %CONVOLUITION  MATRIX

%flip filter
for (i=((extraR/2)+1):(rE-(extraR/2)))
    for (j=((extraR/2)+1):(cE-(extraR/2)))
   
        convMatrix(i-extraR/2,j-extraR/2)=sum(sum(extMat(i-extraR/2:i+extraR/2, j-extraR/2: j+ extraR/2).*signal2));
        
        
    end
    
end
end

