
% 1.1
f = 5; fs = 50;
t = 0: 1/fs : 1;
xn = sin(2 * pi * f * t);
N = length(xn);
fr = (-N/2 : N/2-1) * fs/N;
xf = fftshift(fft(xn));
figure,
subplot(221); plot(t, xn); title('Signal'); xlabel('Time(sec)'); ylabel('Amplitude');
subplot(222); plot(fr, abs(xf)); title('Magnitude'); xlabel('Frequency'); ylabel('|X(f)|');
subplot(223); plot(fr, real(xf)); title('Real'); xlabel('Frequency'); ylabel('Re(X(f))');
subplot(224); plot(fr, imag(xf)); title('Imaginary'); xlabel('Frequency'); ylabel('Im(X(f))');

%1.2
xn = cos(2 * pi * f * t);
N = length(xn);
fr = (-N/2 : N/2-1) * fs/N;
xf = fftshift(fft(xn));
figure,
subplot(221); plot(t, xn); title('Signal'); xlabel('Time(sec)'); ylabel('Amplitude');
subplot(222); plot(fr, abs(xf)); title('Magnitude'); xlabel('Frequency'); ylabel('|X(f)|');
subplot(223); plot(fr, real(xf)); title('Real'); xlabel('Frequency'); ylabel('Re(X(f))');
subplot(224); plot(fr, imag(xf)); title('Imaginary'); xlabel('Frequency'); ylabel('Im(X(f))');

%1.3
xn = square(2 * pi * f * t);
N = length(xn);
fr = (-N/2 : N/2-1) * fs/N;
xf = fftshift(fft(xn));
figure,
subplot(221); plot(t, xn); title('Signal'); xlabel('Time(sec)'); ylabel('Amplitude');
subplot(222); plot(fr, abs(xf)); title('Magnitude'); xlabel('Frequency'); ylabel('|X(f)|');
subplot(223); plot(fr, real(xf)); title('Real'); xlabel('Frequency'); ylabel('Re(X(f))');
subplot(224); plot(fr, imag(xf)); title('Imaginary'); xlabel('Frequency'); ylabel('Im(X(f))');




%1.4
xn=randn(1,10000);
% N = length(xn);
% fs=1/N;
% t = 0: 1/fs : 1;
% fr = (-N/2 : N/2-1) * fs/N;
xf = fftshift(fft(xn));
figure,
subplot(221); plot(xn); title('Signal'); xlabel('Time(sec)'); ylabel('Amplitude');
subplot(222); plot( abs(xf)); title('Magnitude'); xlabel('Frequency'); ylabel('|X(f)|');
subplot(223); plot( real(xf)); title('Real'); xlabel('Frequency'); ylabel('Re(X(f))');
subplot(224); plot( imag(xf)); title('Imaginary'); xlabel('Frequency'); ylabel('Im(X(f))');



% PART 2

%2.1 - 2.2
f1 = 5;
f2=20;
fs=[10,20,25,40,50,100,150];
colorstring = 'kbgry';
figure,
for (i=1:length(fs))

t = 0: 1/fs(i) : 1;
xn = 3*cos(2 * pi * (f1) * t) + 4*sin(2*pi*(f2)*t);
N = length(xn);
fr = (-N/2 : N/2-1) * fs(i)/N;
xf = fftshift(fft(xn));


plot(t,xn,'.-','color',rand(1,3))
hold on
end

%close ALL

figure,

%2.3
%Although the figure is not very clear due to the amount of signals inside,
% we can assert that some of these signals cannot be fully reconstructed
% because of the sampling frequency considered. Thus, in those cases where
% Nyquist theorem is not fulfilled, the reconstructed signal in time domain ]
%does not represent the original considered signal. In these cases, the
%amount of samples is not enough to plot properly

%2.4
for (i=1:length(fs))

t = 0: 1/fs(i) : 1;
xn = 3*cos(2 * pi * (f1) * t) + 4*sin(2*pi*(f2)*t);
N = length(xn);
fr = (-N/2 : N/2-1) * fs(i)/N;
xf = fftshift(fft(xn));

subplot(2,4,i), plot(fr,abs(xf),'b.-')
title(['FFT of sampled signal at frequency of ',num2str(fs(i)),'Hz'])
end

%As we can observe, for frequencies below or equal to 40 Hz (that is twice 
%the higher frequency of our signal, 20hz), we obtained spectrum corrupted
%b%by aliasing (over these Frequencies, Nyquist theorem is not fulfilled).
%However, when plotting the spectrum for sampling frecuencies above 40 Hz,
%we can see how the 20Hz frequency peak is recovered, un thus visible.
%When we continue increasing the sampling frequency, we obtained
%stalibized results of our spectrum.

% PART 3
%LOADING IMAGES}

Mydirectory= ('C:/Users/Ezequiel/Documents/DSP Lab/DSP-TP-1617/Lab4/images/1D-DFT');
srcFiles = dir(strcat(Mydirectory,(''), '/tifImage_*')); 
MyImages=cell(1,length(srcFiles));
for i=1:length(srcFiles)
filename = strcat(Mydirectory,'/',srcFiles(i).name,(''));
 I = imread(filename);
 Myimages{1,i}=I;
end


%PART 4

Mydirectory= ('C:/Users/Ezequiel/Documents/DSP Lab/DSP-TP-1617/Lab4/images/1D-DFT');
srcFiles = dir(strcat(Mydirectory,(''), '/tifImage_*')); 
MyImages=cell(1,length(srcFiles));
ResImages=cell(1,length(srcFiles));
dimx=zeros(3,length(srcFiles));

for i=1:length(srcFiles)
row = 1;
filename = strcat(Mydirectory,'/',srcFiles(i).name,(''));
 I = imread(filename);
 % take first matrix of TIFF images (no information loss, all matrixes are
 %identical)
 
         if length(size(I))>2
             I=I(:,:,1);
         end
 [x,y] = size(I);
 dimx(row,i) = x;
 row = row + 1;
 dimx(row, i) = y;
 row = row + 1;
 dimx(row, i) = x*y;
 %I=mat2gray(I);
 MyImages{1,i}=I;
end

%3.2 Resize and normalize all images
% here we also filter images (sobel configuration) and compute FFT
% spectrums twice per image: the raw image, and the sobel filtered one that
% will be used in the following task

smallest = find(dimx(3,:)==min(dimx(3,:)));
[newR,newC]=size(MyImages{1,smallest});

signals1D=zeros(length(srcFiles),newC);
magnitudeFFT=zeros(length(srcFiles),newC);
SobmagnitudeFFT=zeros(length(srcFiles),newC);

for i=1:length(srcFiles)
    ResImages{1,i}=imresize(mat2gray(MyImages{1,i}), [newR,newC]);
    selImage=ResImages{1,i};
    signals1D(i,:)=selImage(round(newR/2),:);
    magnitudeFFT(i,:)=fftshift(abs(fft(signals1D(i,:))));
    sobelfilterX = [-1 0 1; -2 0 2; -1 0 1];
    sobelfilterY= [-1 -2 -1; 0 0 0; 1 2 1];
    [sobelX]=convFn2(selImage,sobelfilterX);
    [selImage]=convFn2(sobelX,sobelfilterY);
    
    signals1D(i,:)=selImage(round(newR/2),:);
    %compute fft
    SobmagnitudeFFT(i,:)=fftshift(abs(fft(signals1D(i,:))));
  end

%plot FFT spectrums of raw data.
figure, 
subplot(1,2,1), plot (magnitudeFFT(1,:))
title('FFT of 1D Barcode')

subplot(1,2,2), plot (magnitudeFFT(4,:))
title('FFT of 1D Non-Barcode')

%3.4 
%For our classifier, the following strategy was designed:
% 1. Sobel filter all images.
% 2. Compute FFT.
% 3. Estimate the accumulated power spectral density (PSD) per each image.
% 4. Based on the PSD classify using a cutoff all the images using the
%   following rule:
%   if PSD >= Cutoff then image is NON-BARCODE
%   if PDS < Cutoff then image is BARCODE.

% Lets compute the power spectral density per each sobel-filtered image.
% Since we are squaring the signals, we are enhancing higher values much
% more than low ones. This step will help in discriminating the two
% classes.

allPSD=zeros(1,length(srcFiles));
allPSD=sum(((SobmagnitudeFFT(:,:))').^2);

% Then finally define a threshold for our classification task (1D) based in
% only one feature: the accumulated power spectral density of the sobel
% filtered images.
%Based on our data, we proposed a threshold set in the maximam value of our
%  our barcodes class PSD.

BARpositions=[1, 2, 6, 44:54];
Cutoff=max(allPSD(BARpositions));
%Finally, lets apply our linear classifier as follows:
% if PSD >= Cutoff then image is NON-BARCODE
% if PDS < Cutoff then image is BARCODE.

PredictedBarcodes=find(allPSD<Cutoff);
PredictedNONbars=find(allPSD>=Cutoff);
%If we inspected our predicted classes we find:

TP=13; %true positives
FP=10; %false positives
TN=41; %true negatives
FN=0;  %false negatives

Se=100*TP/(TP+FN); %sensitivity
Sp=100*TN/(TN+FP); %specificity
ACC= (TP+TN)/(TP+FP+FN+TN);

%OUR CLASSIFIER OBTAIN 100% sensitivity, 80.4% specificity, and 84.4%
%ACCURACY.

uiwait(msgbox('The classifier obtained 100% sensitivity, 80.4% specificity, and 84.4 accuracy','Title','modal')) 